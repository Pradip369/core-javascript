class Student{
    name = () => "I am name function"
}

function Sir(){
    console.log("I am sir class");
}
export default Student
export {Sir}